INSERT INTO USERS (EMAIL, FIRST_NAME, LAST_NAME, PASSWORD)
VALUES ('user@gmail.com', 'User_First', 'User_Last', '{noop}password'),
       ('admin@javaops.ru', 'Admin_First', 'Admin_Last', '{noop}admin');

INSERT INTO USER_ROLE (ROLE, USER_ID)
VALUES ('USER', 1),
       ('ADMIN', 2),
       ('USER', 2);

INSERT INTO LUNCHES (RESTAURANT_NAME, STARTER, MAIN_COURSE, SALAD, DESSERT, DRINKS )
VALUES ('Харчевня', 'Борщ', 'Плов', 'Винегрет', 'Чизкейк', 'Компот' ),
       ('Харчевня2', 'Щи', 'Курица', 'Винегре', 'Чизкейк', 'Компот');